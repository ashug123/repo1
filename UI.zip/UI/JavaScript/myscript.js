function myfun()
{
    alert('Welcome to MyScript')
    
    console.log('welcome')
}