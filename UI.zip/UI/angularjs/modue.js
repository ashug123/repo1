<div ng-app="myApp" ng-controller="myCtrl">
</div>