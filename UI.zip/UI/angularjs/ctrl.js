 var p=angular.module('myApp',[])
    p.controller('myCtrl',function($scope){
        $scope.firstName="Rohit"
        $scope.lastName="Sharma"
    })