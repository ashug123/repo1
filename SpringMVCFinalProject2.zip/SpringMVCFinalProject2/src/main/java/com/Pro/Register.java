package com.Pro;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Register {

	@RequestMapping("/register")
	public ModelAndView register(HttpServletRequest request,HttpServletResponse response)
	{
		String un=request.getParameter("un");
		String pw1=request.getParameter("pw1");
		String pw2=request.getParameter("pw2");
		
		
		if(!pw1.equals(pw2))
		{
			RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
			String msg="Password mismatch,Please try again";
			request.setAttribute("msg", msg);
			try {
				rd.include(request, response);
				rd.forward(request, response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		else
		{
		
		Connection cn;
		Statement smt;
		ResultSet rs;
		
	
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system","root");
			
			smt=cn.createStatement();
			
			String q="insert into UserRegistration values('"+un+"','"+pw1+"')";
			smt.executeUpdate(q);
			smt.close();
			cn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Signup.jsp");
		mv.addObject("sum","Data Saved");
		
		return mv;
	}
}
