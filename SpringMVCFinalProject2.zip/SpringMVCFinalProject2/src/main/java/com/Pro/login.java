package com.Pro;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class login {

	@RequestMapping("/login")
	public ModelAndView Add(HttpServletRequest request,HttpServletResponse response)
	{
		String un=request.getParameter("un");
		String pw=request.getParameter("pw");
		
		String msg;
	
		Connection cn;
		Statement smt;
		ResultSet rs;
		
		
		if("abcd".equals(un) && "1234".equals(pw))
		{
			msg="You  are Successfully Logged in";
		}
		else
		{
			msg="Login Failed";
		}
		
		ModelAndView mv=new ModelAndView();
		mv.setViewName("Login.jsp");
		mv.addObject("sum",msg);
		
		return mv;
	}
}
